
var deliveryList=[
        {
            "uuid": "2d0319eb-497c-4105-ac2a-eb2fd9484658",
            "version": 0,
            "driverName": null,
            "coorFrom": {
                "uuid": "fc0b61eb-4fef-4112-a22b-a2d3e359f37d",
                "latitude": null,
                "longitude": null,
                "name": null
            },
            "coorTo": {
                "uuid": "ba600ac4-4a41-41eb-a211-7ff4926c916d",
                "latitude": "10.827190474381839",
                "longitude": "106.62873432040215",
                "name": null
            },
            "fromPoint": null,
            "toPoint": "10.827190474381839,106.62873432040215",
            "deliveryName": "Dai Phu Restaurant",
            "deliveryDescription": null,
            "createdDate": 1506281711622,
            "updatedDate": null
        },
        {
            "uuid": "d6106102-e19c-4ada-b960-53043c04f3d1",
            "version": 0,
            "driverName": null,
            "coorFrom": {
                "uuid": "c0ab6d40-0050-476d-a988-6f51656ce7bc",
                "latitude": null,
                "longitude": null,
                "name": null
            },
            "coorTo": {
                "uuid": "1a6818dc-f401-4226-aa30-4d7f00065e9b",
                "latitude": "10.820189971358127",
                "longitude": "106.63170084357262",
                "name": null
            },
            "fromPoint": null,
            "toPoint": "10.820189971358127,106.63170084357262",
            "deliveryName": "Supermarket Coopmart Thang Loi",
            "deliveryDescription": null,
            "createdDate": 1506281687432,
            "updatedDate": null
        },
                {
            "uuid": "2d0319eb-497c-4105-ac2a-eb2fd9484658",
            "version": 0,
            "driverName": null,
            "coorFrom": {
                "uuid": "fc0b61eb-4fef-4112-a22b-a2d3e359f37d",
                "latitude": null,
                "longitude": null,
                "name": null
            },
            "coorTo": {
                "uuid": "ba600ac4-4a41-41eb-a211-7ff4926c916d",
                "latitude": "10.827190474381839",
                "longitude": "106.62873432040215",
                "name": null
            },
            "fromPoint": null,
            "toPoint": "10.827190474381839,106.62873432040215",
            "deliveryName": "Dai Phu Restaurant",
            "deliveryDescription": null,
            "createdDate": 1506281711622,
            "updatedDate": null
        },
        {
            "uuid": "d6106102-e19c-4ada-b960-53043c04f3d1",
            "version": 0,
            "driverName": null,
            "coorFrom": {
                "uuid": "c0ab6d40-0050-476d-a988-6f51656ce7bc",
                "latitude": null,
                "longitude": null,
                "name": null
            },
            "coorTo": {
                "uuid": "1a6818dc-f401-4226-aa30-4d7f00065e9b",
                "latitude": "10.820189971358127",
                "longitude": "106.63170084357262",
                "name": null
            },
            "fromPoint": null,
            "toPoint": "10.820189971358127,106.63170084357262",
            "deliveryName": "Supermarket Coopmart Thang Loi",
            "deliveryDescription": null,
            "createdDate": 1506281687432,
            "updatedDate": null
        },
                {
            "uuid": "2d0319eb-497c-4105-ac2a-eb2fd9484658",
            "version": 0,
            "driverName": null,
            "coorFrom": {
                "uuid": "fc0b61eb-4fef-4112-a22b-a2d3e359f37d",
                "latitude": null,
                "longitude": null,
                "name": null
            },
            "coorTo": {
                "uuid": "ba600ac4-4a41-41eb-a211-7ff4926c916d",
                "latitude": "10.827190474381839",
                "longitude": "106.62873432040215",
                "name": null
            },
            "fromPoint": null,
            "toPoint": "10.827190474381839,106.62873432040215",
            "deliveryName": "Dai Phu Restaurant",
            "deliveryDescription": null,
            "createdDate": 1506281711622,
            "updatedDate": null
        },
        {
            "uuid": "d6106102-e19c-4ada-b960-53043c04f3d1",
            "version": 0,
            "driverName": null,
            "coorFrom": {
                "uuid": "c0ab6d40-0050-476d-a988-6f51656ce7bc",
                "latitude": null,
                "longitude": null,
                "name": null
            },
            "coorTo": {
                "uuid": "1a6818dc-f401-4226-aa30-4d7f00065e9b",
                "latitude": "10.820189971358127",
                "longitude": "106.63170084357262",
                "name": null
            },
            "fromPoint": null,
            "toPoint": "10.820189971358127,106.63170084357262",
            "deliveryName": "Supermarket Coopmart Thang Loi",
            "deliveryDescription": null,
            "createdDate": 1506281687432,
            "updatedDate": null
        },        {
            "uuid": "2d0319eb-497c-4105-ac2a-eb2fd9484658",
            "version": 0,
            "driverName": null,
            "coorFrom": {
                "uuid": "fc0b61eb-4fef-4112-a22b-a2d3e359f37d",
                "latitude": null,
                "longitude": null,
                "name": null
            },
            "coorTo": {
                "uuid": "ba600ac4-4a41-41eb-a211-7ff4926c916d",
                "latitude": "10.827190474381839",
                "longitude": "106.62873432040215",
                "name": null
            },
            "fromPoint": null,
            "toPoint": "10.827190474381839,106.62873432040215",
            "deliveryName": "Dai Phu Restaurant",
            "deliveryDescription": null,
            "createdDate": 1506281711622,
            "updatedDate": null
        },
        {
            "uuid": "d6106102-e19c-4ada-b960-53043c04f3d1",
            "version": 0,
            "driverName": null,
            "coorFrom": {
                "uuid": "c0ab6d40-0050-476d-a988-6f51656ce7bc",
                "latitude": null,
                "longitude": null,
                "name": null
            },
            "coorTo": {
                "uuid": "1a6818dc-f401-4226-aa30-4d7f00065e9b",
                "latitude": "10.820189971358127",
                "longitude": "106.63170084357262",
                "name": null
            },
            "fromPoint": null,
            "toPoint": "10.820189971358127,106.63170084357262",
            "deliveryName": "Supermarket Coopmart Thang Loi",
            "deliveryDescription": null,
            "createdDate": 1506281687432,
            "updatedDate": null
        },        {
            "uuid": "2d0319eb-497c-4105-ac2a-eb2fd9484658",
            "version": 0,
            "driverName": null,
            "coorFrom": {
                "uuid": "fc0b61eb-4fef-4112-a22b-a2d3e359f37d",
                "latitude": null,
                "longitude": null,
                "name": null
            },
            "coorTo": {
                "uuid": "ba600ac4-4a41-41eb-a211-7ff4926c916d",
                "latitude": "10.827190474381839",
                "longitude": "106.62873432040215",
                "name": null
            },
            "fromPoint": null,
            "toPoint": "10.827190474381839,106.62873432040215",
            "deliveryName": "Dai Phu Restaurant",
            "deliveryDescription": null,
            "createdDate": 1506281711622,
            "updatedDate": null
        },
        {
            "uuid": "d6106102-e19c-4ada-b960-53043c04f3d1",
            "version": 0,
            "driverName": null,
            "coorFrom": {
                "uuid": "c0ab6d40-0050-476d-a988-6f51656ce7bc",
                "latitude": null,
                "longitude": null,
                "name": null
            },
            "coorTo": {
                "uuid": "1a6818dc-f401-4226-aa30-4d7f00065e9b",
                "latitude": "10.820189971358127",
                "longitude": "106.63170084357262",
                "name": null
            },
            "fromPoint": null,
            "toPoint": "10.820189971358127,106.63170084357262",
            "deliveryName": "Supermarket Coopmart Thang Loi",
            "deliveryDescription": null,
            "createdDate": 1506281687432,
            "updatedDate": null
        }
    ]

module.exports = {deliveryList};
