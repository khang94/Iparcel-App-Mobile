/*
* @providesModule Constants
*/


module.exports = {

     // Server
     serverUrl: 'http://45.119.81.84:7575/',

     AUTH_KEY_FCM : 'AAAA4zGisBc:APA91bEw7OJ9nbc89YOoT3NaYfCuE3nhH_jXbP8gHbIQ-iWHun4iZ7OKB_vd9YWnRJ-jJ22S46QWy7-NYKhbHX6hMjOJbyzsKm6KbJ9IdFmlrgPoywfzcVkOKqtGUhoGOGfoJHZeoXst'
};
