import "./src/App";
/*import React, { Component } from 'react';
import {
    AppRegistry
} from 'react-native';
import App from './src/App'

AppRegistry.registerComponent('MyMap', () => App);*/